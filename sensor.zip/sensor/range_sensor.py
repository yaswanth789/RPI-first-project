#!/usr/bin/python
import sys
import Adafruit_DHT
import requests
import datetime
import os
import RPi.GPIO as GPIO
import time
import mcp3008

flg =0
url="http://127.0.0.1:8000/weather/get"

while True:
    GPIO.setmode(GPIO.BCM)

    TRIG = 23
    ECHO = 24
    

    GPIO.setup(TRIG,GPIO.OUT)
    GPIO.setup(ECHO,GPIO.IN)
   
    GPIO.output(TRIG, False)
    #if (flg == 0):
    print ("Waiting For Sensor To Settle")
    time.sleep(2)

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO)==0:
      pulse_start = time.time()

    while GPIO.input(ECHO)==1:
      pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start

    distance = pulse_duration * 17150

    distance = round(distance, 2)
    distance = 300 - distance
    print( "Distance: "+ str(distance)+"cm")
    flg=0
    humidity, temperature = Adafruit_DHT.read_retry(11, 4)
    Time =datetime.datetime.now()
    m1 = mcp3008.readadc(5)
    m2 = mcp3008.readadc(7)
    water=mcp3008.readadc(6)
    print(water)
    m1 = (m1*100)/1024
    if m1>60:
        k1=' First plant in dry soil'
    else:
        k1='First plant in watery soil'
    if m1>60 :
             GPIO.output(26, True)
             time.sleep(5)
             GPIO.output(26,False)
    else :
             GPIO.output(26,False)
    m2 = (m2*100)/1024
    if m2>60:
        k2='Second plant in dry soil'
    else:
        k2='Second plant in watery soil'
    '''if m2>60 :
             GPIO.output(26, True)
             time.sleep(5)
             GPIO.output(26,False)
    else :
             GPIO.output(26,False)'''
    GPIO.setup(23,GPIO.IN)
    state=GPIO.input(23)
    if water>150:
        r = "raining"
    else:
        r = "not raining"
    print(r)    
    data = {'temperature':temperature,'humidity':humidity,'Time':Time,'SoilMoisture1':m1,'soil1':k1,'level':distance,'rain':r,'SoilMoisture2':m2,'soil2':k2}        
    print(k)
    print (temperature,humidity,Time,m1,m2,distance)
    requests.get(url,params=data)
    GPIO.cleanup()
