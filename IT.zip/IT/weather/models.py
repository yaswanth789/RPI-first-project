# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
#Create your models here.
class plant(models.Model):
    pid1 = models.IntegerField(primary_key=True)
    latitude = models.FloatField(default=0)
    longitude = models.FloatField(default=0)
    def __str__(self):
        return str(self.pid1)


class Temperature(models.Model):
	#temparature class objects
	pid = models.ForeignKey(plant,null=True)
	tem_value=models.CharField(max_length=250)
	hum_value=models.CharField(max_length=250)
	time_value=models.CharField(max_length=250)
	soil_value1=models.CharField(max_length=250)
	soil_value2=models.CharField(max_length=250)
        soil1=models.CharField(max_length=250)
	soil2=models.CharField(max_length=250)
        level_value=models.CharField(max_length=250)
	rain_value=models.CharField(max_length=250)
	def __str__(self):
		return (self.tem_value + ',' + self.hum_value + ',' + self.time_value + ',' + self.soil_value1 +','  + self.soil1  + ',' + self.level_value + ',' +self.rain_value + ',' + self.tem_value + ',' + self.hum_value + ',' + self.time_value + ',' + self.soil_value2 +','  + self.soil2  + ',' + self.level_value + ',' +self.rain_value)


