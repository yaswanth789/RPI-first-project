from __future__ import unicode_literals
from .models import Temperature,plant 
from django.shortcuts import render
from django.http import HttpResponse
 
import datetime
from django.contrib.auth import authenticate,login
from django.views.decorators.csrf import csrf_exempt
import json

from django.http import JsonResponse, HttpResponse,HttpResponseRedirect

from django.contrib.auth.decorators import login_required
from .forms import UserForm,plantForm
from django.core import serializers

# Create your views here.
#get the sensor values from the url written in the sensor code using GET method
def getdata(request):
	if request.method=='GET' :
		temp_value=request.GET['temperature']
		humi_value=request.GET['humidity']
		time_value=request.GET['Time']
		Soil_value1=request.GET['SoilMoisture1']
		Soil_value2=request.GET['SoilMoisture2']		
		soil1=request.GET['soil1']
		soil2=request.GET['soil2']                
		level_value=request.GET['level']
		rain_value=request.GET['rain']		
		t_obj=Temperature()
		t_obj.tem_value= temp_value
		t_obj.hum_value=humi_value
		t_obj.time_value=time_value
		t_obj.soil_value1=Soil_value1
		t_obj.soil_value2=Soil_value2
		t_obj.soil1=soil1
		t_obj.soil2=soil2                
		t_obj.rain_value=rain_value
		t_obj.level_value=level_value
		t_obj.save()
		return HttpResponse("data saved in db")
	else:
		return HttpResponse("error")
#sending the values to the index.html to display them
@login_required
def index(request):
    temp_data=Temperature.objects.all()[len(Temperature.objects.all())-1]
    data = str(temp_data).split(",")
    tem_data = str(data[0])
    hum_data = str(data[1])
    time_value = str(data[2])
    soil_value1 = str(data[3])
    soil_value2 = str(data[4])
    soil1 = str(data[5])
    soil2 = str(data[6])
    level_value = str(data[7])
    rain_value = str(data[8])
    context={'tem':tem_data ,'hum':hum_data,'time':time_value,'Soil_Moisture1':soil_value1,'Soil_Moisture2':soil_value2,'soil1':soil1,'soil2':soil2,'water_level':level_value,'rain':rain_value}
    return render(request,'index.html',context)
@login_required
def Maps(request):
    temp_data=Temperature.objects.all()[len(Temperature.objects.all())-1]
    data = str(temp_data).split(",")
    tem_data = str(data[0])
    hum_data = str(data[1])
    time_value = str(data[2])
    soil_value1 = str(data[3])
    soil_value2 = str(data[4])
    soil1 = str(data[5])
    soil2 = str(data[6])
    level_value = str(data[7])
    rain_value = str(data[8])
    context={'tem':tem_data ,'hum':hum_data,'time':time_value,'Soil_Moisture1':soil_value1,'Soil_Moisture2':soil_value2,'soil1':soil1,'soil2':soil2,'water_level':level_value,'rain':rain_value}
    return render(request,'sensor.html',context)


#function to open the contact.html page
def contact(request):
        if request.method == 'GET':
            return render(request,'contact.html')

# Create your views here.
#signin function definition and way to call the sign.in html

@csrf_exempt
def signin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                flag=1
                #return render(request, 'index.html')
                return HttpResponseRedirect('/weather')
            else:
                return render(request, 'signin.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'signin.html', {'error_message': 'Invalid login'})
    return render(request, 'signin.html')

#signup function definition and way to call the signup.html
@csrf_exempt
def signup(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user.set_password(password)
        user.save()
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                #return render(request,'index.html')
                return HttpResponseRedirect('/weather')
    context = {
        "form": form,
    }
    return render(request, 'signup.html', context)
def plants(requests): 
    all_p=plant.objects.all() 
    arr=[] 
    for p in all_p: 
        arr.append(p.pid1)
        print(arr)
    return JsonResponse({'pids':arr},safe=True)


def add_plant(request,pi):
    a = plant.objects.create(pid1=pi)
    a.save()

def pindex(request,pid1): 
    all_plants = plant.objects.all() 
    html = {}
    html = []
    for plants in all_plants:
        if(str(plants.pid1)) == str(pid1): 
            html = {"pid1":plants.pid1,"latitude":plants.latitude,"longitude":plants.longitude} 
    html1 = list(map(lambda x: x['fields'],json.loads(serializers.serialize('json',Temperature.objects.filter(pid=pid1)))))
    return JsonResponse({"loc":html, "values":html1}, safe=False)

@csrf_exempt
def detail(request,pid1):
    if not request.user.is_authenticated():
        return render(request, 'weather/signin.html')
    else:
        user = request.user
        return render(request, 'weather/index.html', {'weather': plant, 'user': user})

#function to add plants
def addplants(request):
    form = plantForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            pid1 = form.cleaned_data['pid1']
            longitude = form.cleaned_data['longitude']
            latitude = form.cleaned_data['latitude']
            print(pid1)
            print(longitude)
            foo = plant.objects.create(pid1 = int(pid1),latitude = float(latitude), longitude = float(longitude))
            return HttpResponseRedirect('/weather') #we are redirected to another page
        else:
            form = plantForm()
    return render(request,'addplants.html',{'form':form})



