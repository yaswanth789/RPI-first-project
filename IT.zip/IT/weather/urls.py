
from django.conf.urls import url
from . import views
urlpatterns = [
    #urls to be allowed to open the html pages respecctively
    url(r'^get/$', views.getdata ,name ="get"),
    url(r'^$', views.index ,name = "index"),
    url(r'^(?P<pid1>[0-9]+)/$', views.pindex, name='detail'),
    url(r'^contact/$',views.contact ,name = "contact" ),
    url(r'^maps/$',views.Maps ,name = "maps" ),
    #url(r'^profile/$',views.profile ,name = "profile" ),
    url(r'^signin/$',views.signin ,name = "login_user" ),
    #url(r'^add/(?P<pi>[0-9]+)',views.add_plant,name='add'),
    #url(r'^plants/', views.plants, name='plants'),
    url(r'^addplants/$', views.addplants, name='addplants'),
    url(r'^signup/$',views.signup ,name = "register" )
]
